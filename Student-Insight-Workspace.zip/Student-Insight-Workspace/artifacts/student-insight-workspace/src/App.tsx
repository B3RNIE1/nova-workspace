import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import {
  Award,
  BarChart3,
  BookOpen,
  Calculator,
  CalendarPlus,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Clock3,
  Coffee,
  ExternalLink,
  Flame,
  Lightbulb,
  ListChecks,
  Lock,
  MessageCircle,
  Moon,
  Music,
  NotebookPen,
  PanelRight,
  Pause,
  Play,
  Plus,
  RefreshCcw,
  RotateCcw,
  Save,
  Send,
  Settings,
  SkipForward,
  Sparkles,
  StickyNote,
  Target,
  Timer,
  Trash2,
  Trophy,
  WandSparkles,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type View = 'graph' | 'calendar' | 'notes' | 'calculator' | 'quiz' | 'settings';
type TimerMode = 'study' | 'short' | 'long';
type QuestionType = 'multiple' | 'true-false';
type QuizQuestion = {
  id: string;
  prompt: string;
  answer: string;
  options: string[];
  type: QuestionType;
  explanation: string;
};
type Quiz = {
  id: string;
  questions: QuizQuestion[];
  createdAt: string;
  sourceWords: number;
};
type Profile = { xp: number; claimedQuizIds: string[] };
type Assignment = { id: string; title: string; date: string; course: string };
type StickyNote = { id: string; title: string; content: string; color: 'violet' | 'mint' | 'amber' | 'rose'; updatedAt: string };
type ChatMessage = { role: 'assistant' | 'user'; text: string };
type SoundscapeMix = { focus: number; rain: number; library: number };
type ThemeSettings = { ambientGrid: boolean; compact: boolean; reducedMotion: boolean; highContrast: boolean };

const queryClient = new QueryClient();
const STORAGE_PREFIX = 'student-insight:';
const TIMER_SECONDS = { study: 25 * 60, short: 5 * 60, long: 15 * 60 };
const BREAK_WINDOW_SECONDS = 30 * 60;
const VERB_PATTERN = /^(is|are|was|were|helps|help|improves|strengthens|protects|enables|increases|reduces|supports|uses|creates|contains|stores|drives|builds|makes|means|forms|controls|produces|requires|allows|can|has|have|does|provides|includes)\b/i;
const sampleNotes =
  'Attention is a limited resource, not a character trait. Deep work improves when distractions are made difficult to reach. The hippocampus helps consolidate new memories during sleep. Retrieval practice strengthens learning more than passive rereading. Short breaks protect the quality of sustained focus.';
const sampleStickyNotes: StickyNote[] = [
  { id: 'starter-1', title: 'Next focus block', content: 'Start with the hardest idea while the signal is clear.', color: 'violet', updatedAt: new Date().toISOString() },
  { id: 'starter-2', title: 'Remember', content: 'Retrieval beats rereading. Ask yourself before looking back.', color: 'mint', updatedAt: new Date().toISOString() },
];

function makeId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function load<T>(key: string, fallback: T): T {
  try {
    const saved = window.localStorage.getItem(STORAGE_PREFIX + key);
    return saved ? (JSON.parse(saved) as T) : fallback;
  } catch {
    return fallback;
  }
}

function useStored<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(() => load(key, fallback));
  useEffect(() => {
    window.localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  }, [key, value]);
  return [value, setValue] as const;
}

function formatTime(seconds: number) {
  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = (seconds % 60).toString().padStart(2, '0');
  return `${mins}:${secs}`;
}

function dayKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}

function getWeek() {
  const today = new Date();
  const start = new Date(today);
  const mondayOffset = (today.getDay() + 6) % 7;
  start.setDate(today.getDate() - mondayOffset);
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(start);
    date.setDate(start.getDate() + index);
    return { key: dayKey(date), label: date.toLocaleDateString('en-US', { weekday: 'short' }).slice(0, 2), date };
  });
}

function getLevelTitle(level: number) {
  if (level >= 25) return 'Elite Mastermind';
  if (level >= 10) return 'Focused Scholar';
  if (level >= 5) return 'Deep Thinker';
  return 'Novice';
}

function parseSentence(sentence: string) {
  const clean = sentence.replace(/[.!?]+$/, '').trim();
  const words = clean.split(/\s+/);
  const verbIndex = words.findIndex((word, index) => index > 0 && VERB_PATTERN.test(word));

  if (verbIndex <= 0 || verbIndex >= words.length - 1) {
    return {
      answer: words.slice(0, Math.max(1, Math.min(3, words.length - 1))).join(' '),
      verb: '',
      predicate: clean,
      prompt: 'Which idea is supported by your notes?',
      sentence: clean,
    };
  }

  const answer = words.slice(0, verbIndex).join(' ');
  const verb = words[verbIndex];
  const predicate = words.slice(verbIndex + 1).join(' ');
  return {
    answer,
    verb,
    predicate,
    prompt: `What ${verb.toLowerCase()} ${predicate}?`,
    sentence: clean,
  };
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedErrorBoundary />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

function RoutedErrorBoundary() {
  const [location] = useLocation();
  return (
    <ErrorBoundary resetKey={location}>
      <Switch>
        <Route path="/" component={Workspace} />
        <Route component={Workspace} />
      </Switch>
    </ErrorBoundary>
  );
}

function Workspace() {
  const [view, setView] = useStored<View>('view', 'graph');
  const [profile, setProfile] = useStored<Profile>('profile', { xp: 1240, claimedQuizIds: [] });
  const [profileName, setProfileName] = useStored<string>('profile-name', 'Ari Rowan');
  const [studyLogs, setStudyLogs] = useStored<Record<string, number>>('study-logs', {});
  const [goalHours, setGoalHours] = useStored<number>('goal-hours', 10);
  const [notes, setNotes] = useStored<string>('notes', sampleNotes);
  const [assignments, setAssignments] = useStored<Assignment[]>('assignments', []);
  const [stickyNotes, setStickyNotes] = useStored<StickyNote[]>('sticky-notes', sampleStickyNotes);
  const [calendarMonth, setCalendarMonth] = useStored<string>('calendar-month', `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`);
  const [calculatorExpression, setCalculatorExpression] = useStored<string>('calculator-expression', '');
  const [calculatorResult, setCalculatorResult] = useStored<string>('calculator-result', '');
  const [themeSettings, setThemeSettings] = useStored<ThemeSettings>('theme-settings', { ambientGrid: true, compact: false, reducedMotion: false, highContrast: false });
  const [soundscapeMix, setSoundscapeMix] = useStored<SoundscapeMix>('soundscape-mix', { focus: 35, rain: 20, library: 15 });
  const [quiz, setQuiz] = useStored<Quiz | null>('quiz', null);
  const [quizIndex, setQuizIndex] = useStored<number>('quiz-index', 0);
  const [quizAnswers, setQuizAnswers] = useStored<Record<number, string>>('quiz-answers', {});
  const [quizResults, setQuizResults] = useStored<Record<number, boolean>>('quiz-results', {});
  const [mode, setMode] = useStored<TimerMode>('timer-mode', 'study');
  const [timerSeconds, setTimerSeconds] = useStored<number>('timer-seconds', TIMER_SECONDS.study);
  const [timerRunning, setTimerRunning] = useStored<boolean>('timer-running', false);
  const [breakOpen, setBreakOpen] = useState(false);
  const [breakSeconds, setBreakSeconds] = useState(BREAK_WINDOW_SECONDS);
  const [breakStartedAt, setBreakStartedAt] = useState(() => Date.now());
  const [quizLength, setQuizLength] = useStored<number>('quiz-length', 10);
  const [questionType, setQuestionType] = useStored<QuestionType>('question-type', 'multiple');
  const [chatMessages, setChatMessages] = useStored<ChatMessage[]>('sidekick-messages', [{ role: 'assistant', text: 'I’m your local study sidekick. Ask me about your notes, your next focus move, or your quiz.' }]);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');

  const week = useMemo(getWeek, []);
  const todayMinutes = studyLogs[dayKey()] ?? 0;
  const weeklyMinutes = week.reduce((sum, day) => sum + (studyLogs[day.key] ?? 0), 0);
  const goalMinutes = goalHours * 60;
  const progress = Math.min(100, goalMinutes ? Math.round((weeklyMinutes / goalMinutes) * 100) : 0);
  const level = Math.floor(profile.xp / 500) + 1;
  const levelTitle = getLevelTitle(level);
  const levelStart = (level - 1) * 500;
  const levelProgress = ((profile.xp - levelStart) / 500) * 100;

  useEffect(() => {
    if (!timerRunning) return;
    const interval = window.setInterval(() => {
      setTimerSeconds((seconds) => {
        const next = Math.max(0, seconds - 1);
        if (mode === 'study' && next % 60 === 0) {
          setStudyLogs((logs) => ({ ...logs, [dayKey()]: (logs[dayKey()] ?? 0) + 1 }));
          setProfile((current) => ({ ...current, xp: current.xp + 10 }));
        }
        if (seconds <= 1) {
          setTimerRunning(false);
          return TIMER_SECONDS[mode];
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [mode, setBreakOpen, setProfile, setStudyLogs, setTimerRunning, setTimerSeconds, timerRunning]);

  useEffect(() => {
    const tick = () => {
      const remaining = Math.max(0, BREAK_WINDOW_SECONDS - Math.floor((Date.now() - breakStartedAt) / 1000));
      setBreakSeconds(remaining);
      if (remaining === 0) setBreakOpen(true);
    };
    tick();
    const interval = window.setInterval(tick, 1000);
    return () => window.clearInterval(interval);
  }, [breakStartedAt]);

  const selectMode = (next: TimerMode) => {
    setMode(next);
    setTimerRunning(false);
    setTimerSeconds(TIMER_SECONDS[next]);
  };

  const resetQuiz = () => {
    setQuizIndex(0);
    setQuizAnswers({});
    setQuizResults({});
  };

  const generateQuiz = () => {
    const notesText = notes.trim();
    const sentences = notesText.split(/[.!?]+\s+/).filter(s => s.trim().length > 0);
    const source = sentences.length ? sentences : sampleNotes.split(/[.!?]+\s+/).filter(s => s.trim().length > 0);
    const parsedSource = source.map((sentence) => parseSentence(sentence.trim()));
    const distractorPool = [...new Set(parsedSource.map((item) => item.answer.length > 1 ? item.answer : item.sentence))];
    const questionCount = Math.min(quizLength, parsedSource.length);
    const questions: QuizQuestion[] = Array.from({ length: questionCount }, (_, index) => {
      const parsed = parsedSource[index];
      const isTrueFalse = questionType === 'true-false';
      const isFalse = isTrueFalse && index % 2 === 1;
      const statement = isFalse && parsed.verb
        ? `${parsed.answer} ${parsed.verb} not ${parsed.predicate}`
        : parsed.sentence;
      const answer = isTrueFalse ? (isFalse ? 'False' : 'True') : parsed.answer;
      const prompt = isTrueFalse
        ? `True or false: ${statement}.`
        : parsed.prompt;
      const distractors = distractorPool
        .filter((value) => value.toLowerCase() !== parsed.answer.toLowerCase())
        .sort(() => Math.random() - 0.5)
        .slice(0, 3);
      return {
        id: `${Date.now()}-${index}`,
        prompt,
        answer,
        options: isTrueFalse ? ['True', 'False'] : [parsed.answer, ...distractors].slice(0, 4).sort(() => Math.random() - 0.5),
        type: questionType,
        explanation: `Your notes state: “${parsed.sentence}.”`,
      };
    });
    setQuiz({ id: `${Date.now()}`, questions, createdAt: new Date().toISOString(), sourceWords: notes.trim().split(/\s+/).filter(Boolean).length });
    resetQuiz();
  };

  const answerQuestion = (answer: string) => {
    if (!quiz || quizResults[quizIndex] !== undefined) return;
    const question = quiz.questions[quizIndex];
    const isCorrect = answer === question.answer;
    setQuizAnswers((answers) => ({ ...answers, [quizIndex]: answer }));
    setQuizResults((results) => ({ ...results, [quizIndex]: isCorrect }));
    if (isCorrect) setProfile((current) => ({ ...current, xp: current.xp + 8 }));
  };

  const claimBonus = () => {
    if (!quiz || profile.claimedQuizIds.includes(quiz.id)) return;
    setProfile((current) => ({ ...current, xp: current.xp + 60, claimedQuizIds: [...current.claimedQuizIds, quiz.id] }));
  };

  const sendSidekick = () => {
    const prompt = chatInput.trim();
    if (!prompt) return;
    const lowerPrompt = prompt.toLowerCase();
    const ignoredTerms = new Set(['what', 'when', 'where', 'which', 'does', 'the', 'for', 'about', 'tell', 'show', 'please', 'assignment', 'assignments', 'calendar', 'due', 'date', 'dates', 'deadline']);
    const queryTerms = lowerPrompt.split(/[^a-z0-9]+/).filter((term) => term.length > 2 && !ignoredTerms.has(term));
    const matchingAssignments = assignments.filter((assignment) => {
      const searchable = `${assignment.title} ${assignment.course}`.toLowerCase();
      return queryTerms.some((term) => searchable.includes(term));
    });
    const asksAboutCalendar = /\b(due|when|date|dates|deadline|calendar|assignment|assignments)\b/i.test(prompt);
    const upcomingAssignments = assignments
      .filter((assignment) => assignment.date >= dayKey())
      .sort((first, second) => first.date.localeCompare(second.date));
    const assignmentMatches = matchingAssignments.length ? matchingAssignments : upcomingAssignments;
    let reply = '';
    if (asksAboutCalendar || matchingAssignments.length) {
      reply = assignmentMatches.length
        ? assignmentMatches.map((assignment) => `${assignment.title} (${assignment.course}) is due ${new Date(`${assignment.date}T00:00:00`).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}.`).join(' ')
        : 'I could not find a matching calendar event yet. Add the assignment in Calendar and I’ll keep its due date handy.';
    } else if (lowerPrompt.includes('quiz') || lowerPrompt.includes('test')) {
      reply = quiz
        ? `Your current quiz has ${quiz.questions.length} questions. Keep moving one question at a time; every correct answer adds XP.`
        : 'Your quiz studio is ready. Open Quiz Studio, choose a length, and generate a sentence-by-sentence recall test from your notes.';
    } else if (lowerPrompt.includes('focus') || lowerPrompt.includes('study') || lowerPrompt.includes('next')) {
      reply = `Your next focus move: run a ${mode === 'study' ? '25-minute study block' : 'study block after this break'}, then take a short reset. You have ${weeklyMinutes} study minutes logged this week.`;
    } else if (lowerPrompt.includes('summar') || lowerPrompt.includes('what')) {
      reply = notes.length > 180 ? `${notes.slice(0, 180).trim()}…` : notes || 'Add notes first and I’ll reflect them back to you.';
    } else if (lowerPrompt.includes('note')) {
      reply = stickyNotes.length ? `Your latest note is “${stickyNotes[0].title}.” Keep it visible while you work.` : 'Create a sticky note in the Corkboard so I can help you keep the next idea visible.';
    }
    setChatMessages((current) => [...current, { role: 'user', text: prompt }, { role: 'assistant', text: reply }]);
    setChatInput('');
  };

  const evaluateCalculator = () => {
    if (!calculatorExpression.trim()) return;
    try {
      if (!/^[0-9+\-*/().%\s]+$/.test(calculatorExpression)) throw new Error('Unsupported characters');
      const result = Function(`"use strict"; return (${calculatorExpression})`)();
      setCalculatorResult(Number.isFinite(result) ? String(result) : 'Undefined');
    } catch {
      setCalculatorResult('Check expression');
    }
  };

  return (
    <div className={`app-shell ${themeSettings.ambientGrid ? 'noise' : ''} ${themeSettings.compact ? 'compact-mode' : ''} ${themeSettings.reducedMotion ? 'reduced-motion' : ''} ${themeSettings.highContrast ? 'high-contrast' : ''} text-foreground`}>
      <Sidebar view={view} username={profileName} onChange={setView} />
      <main className="main-content min-h-[100dvh] pl-0 md:pl-[76px]">
        <div className="mx-auto max-w-[1500px] px-5 pb-28 pt-6 sm:px-8 md:px-10 md:pb-10">
          <TopBar view={view} profile={profile} profileName={profileName} level={level} levelTitle={levelTitle} onChange={setView} />
          {view === 'graph' ? (
            <GraphView
              mode={mode}
              timerSeconds={timerSeconds}
              timerRunning={timerRunning}
              onModeChange={selectMode}
              onToggle={() => setTimerRunning((running) => !running)}
               onReset={() => {
                setTimerRunning(false);
                 setTimerSeconds(TIMER_SECONDS[mode]);
              }}
              studyLogs={studyLogs}
              week={week}
              weeklyMinutes={weeklyMinutes}
              todayMinutes={todayMinutes}
              goalHours={goalHours}
              goalMinutes={goalMinutes}
              progress={progress}
              onGoalChange={setGoalHours}
              xp={profile.xp}
              level={level}
               levelProgress={levelProgress}
               levelTitle={levelTitle}
               soundscapeMix={soundscapeMix}
               onSoundscapeChange={setSoundscapeMix}
              onOpenBreak={() => {
                setBreakOpen(true);
              }}
            />
          ) : view === 'calendar' ? (
            <CalendarView assignments={assignments} month={calendarMonth} onMonthChange={setCalendarMonth} onAdd={(assignment) => setAssignments((current) => [...current, assignment])} onDelete={(id) => setAssignments((current) => current.filter((assignment) => assignment.id !== id))} />
          ) : view === 'notes' ? (
            <NotesView notes={stickyNotes} profileName={profileName} onNameChange={setProfileName} onChange={setStickyNotes} />
          ) : view === 'calculator' ? (
            <CalculatorView expression={calculatorExpression} result={calculatorResult} onExpressionChange={setCalculatorExpression} onEvaluate={evaluateCalculator} onClear={() => { setCalculatorExpression(''); setCalculatorResult(''); }} />
          ) : view === 'settings' ? (
            <SettingsView settings={themeSettings} username={profileName} onChange={setThemeSettings} onUsernameChange={setProfileName} />
          ) : (
            <QuizView
              notes={notes}
              setNotes={setNotes}
              quizLength={quizLength}
              setQuizLength={setQuizLength}
              questionType={questionType}
              setQuestionType={setQuestionType}
              quiz={quiz}
              quizIndex={quizIndex}
              setQuizIndex={setQuizIndex}
              quizAnswers={quizAnswers}
              quizResults={quizResults}
              onGenerate={generateQuiz}
              onAnswer={answerQuestion}
              onReset={resetQuiz}
              onClaimBonus={claimBonus}
              bonusClaimed={quiz ? profile.claimedQuizIds.includes(quiz.id) : false}
            />
          )}
        </div>
      </main>
      {breakOpen && (
        <BreakOverlay
          seconds={breakSeconds}
          onSkip={() => {
            setBreakOpen(false);
            setBreakStartedAt(Date.now());
            setBreakSeconds(BREAK_WINDOW_SECONDS);
          }}
        />
      )}
          <Sidekick open={chatOpen} messages={chatMessages} input={chatInput} onToggle={() => setChatOpen((open) => !open)} onInput={setChatInput} onSend={sendSidekick} />
    </div>
  );
}

function Sidebar({ view, username, onChange }: { view: View; username: string; onChange: (view: View) => void }) {
  const initials = username.split(' ').map(n => n[0]).join('').toUpperCase();
  return (
    <aside className="sidebar-rail fixed left-0 top-0 z-40 h-full border-r border-sidebar-border bg-sidebar">
      <div className="sidebar-inner flex h-full flex-col items-center gap-8 px-3 py-6">
        <div className="brand-area flex w-full items-center justify-center overflow-hidden">
          <img src="/novalogo.png" alt="NOVA Workspace" className="sidebar-logo" />
        </div>
        <div className="nav-divider h-px w-full bg-sidebar-border" />
        <nav className="sidebar-nav flex w-full flex-1 flex-col gap-2">
          <NavItem active={view === 'graph'} label="Productivity" icon={<BarChart3 size={19} />} onClick={() => onChange('graph')} testId="button-nav-productivity" />
          <NavItem active={view === 'calendar'} label="Calendar" icon={<CalendarDays size={19} />} onClick={() => onChange('calendar')} testId="button-nav-calendar" />
          <NavItem active={view === 'notes'} label="Notes / Corkboard" icon={<StickyNote size={19} />} onClick={() => onChange('notes')} testId="button-nav-notes" />
          <NavItem active={view === 'calculator'} label="Scientific calculator" icon={<Calculator size={19} />} onClick={() => onChange('calculator')} testId="button-nav-calculator" />
          <NavItem active={view === 'quiz'} label="Quiz studio" icon={<WandSparkles size={19} />} onClick={() => onChange('quiz')} testId="button-nav-quiz-studio" />
          <div className="mt-auto">
            <NavItem active={view === 'settings'} label="Preferences" icon={<Settings size={19} />} onClick={() => onChange('settings')} testId="button-nav-preferences" />
          </div>
        </nav>
        <div className="profile-area flex w-full items-center gap-3 overflow-hidden rounded-xl border border-sidebar-border bg-sidebar-accent px-2 py-2.5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent font-serif font-bold text-accent-foreground">{initials || 'A'}</div>
          <div className="brand-copy">
            <div className="whitespace-nowrap text-xs font-semibold text-foreground">{username || 'Workspace'}</div>
            <div className="whitespace-nowrap font-mono text-[9px] text-muted-foreground">focus operator</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function NavItem({ active, label, icon, onClick, testId }: { active?: boolean; label: string; icon: React.ReactNode; onClick: () => void; testId: string }) {
  return (
    <button
      type="button"
      data-testid={testId}
      aria-label={label}
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition-all ${active ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-[0_10px_25px_rgba(178,126,255,.16)]' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-foreground'}`}
    >
      <span className="shrink-0">{icon}</span>
      <span className="nav-label text-xs font-semibold">{label}</span>
    </button>
  );
}

function TopBar({ view, profile, profileName, level, levelTitle, onChange }: { view: View; profile: Profile; profileName: string; level: number; levelTitle: string; onChange: (view: View) => void }) {
  const viewCopy = {
    graph: ['Productivity console', `Good evening, ${profileName.split(' ')[0]}.`, 'Your attention has a shape today. Make the next block count.'],
    calendar: ['Calendar / command board', 'Make the week visible.', 'Keep assignments, deadlines, and the next action in one place.'],
    notes: ['Notes / corkboard', 'Keep the good ideas close.', 'A flexible surface for thoughts, reminders, and unfinished questions.'],
    calculator: ['Scientific calculator', 'Numbers, without the noise.', 'A clean scratchpad for the calculations your study session needs.'],
    quiz: ['Quiz studio', 'Turn notes into momentum.', 'A private test bench for the ideas you want to keep.'],
    settings: ['Preferences', 'Tune your study environment.', 'Small adjustments can make a long session feel more like yours.'],
  }[view];
  return (
    <header className="mb-9">
      <div className="header-wordmark-row flex min-h-12 items-center justify-center">
        <img src="/wordmark.png" alt="NOVA Workspace" className="wordmark-image" />
      </div>
      <div className="mt-7 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.22em] text-accent">
            <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-accent" /> {viewCopy[0]}
          </div>
          <h1 className="font-serif text-3xl font-bold tracking-[-.04em] text-foreground sm:text-4xl">
            {viewCopy[1]}
          </h1>
          <p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">
            {viewCopy[2]}
          </p>
        </div>
        <div className="flex items-center gap-2 self-start rounded-2xl border border-border bg-card/60 p-1.5 lg:self-center">
           <button type="button" data-testid="button-switch-graph" onClick={() => onChange('graph')} className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition ${view === 'graph' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
             <BarChart3 size={15} /> Productivity
          </button>
          <button type="button" data-testid="button-switch-quiz" onClick={() => onChange('quiz')} className={`flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-semibold transition ${view === 'quiz' ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <Sparkles size={15} /> Quiz studio
          </button>
          <div className="ml-1 hidden h-8 w-px bg-border sm:block" />
          <div className="hidden items-center gap-2 px-2 sm:flex" data-testid="text-topbar-xp">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent/15 text-accent"><Zap size={14} /></div>
             <div><div className="font-mono text-[9px] text-muted-foreground">LEVEL {level} · {levelTitle}</div><div className="text-xs font-bold text-foreground">{profile.xp.toLocaleString()} XP</div></div>
          </div>
        </div>
      </div>
    </header>
  );
}

function GraphView({
  mode, timerSeconds, timerRunning, onModeChange, onToggle, onReset, studyLogs, week, weeklyMinutes, todayMinutes, goalHours, goalMinutes, progress, onGoalChange, xp, level, levelTitle, levelProgress, soundscapeMix, onSoundscapeChange, onOpenBreak,
}: {
  mode: TimerMode; timerSeconds: number; timerRunning: boolean; onModeChange: (mode: TimerMode) => void; onToggle: () => void; onReset: () => void;
  studyLogs: Record<string, number>; week: { key: string; label: string; date: Date }[]; weeklyMinutes: number; todayMinutes: number; goalHours: number; goalMinutes: number; progress: number; onGoalChange: (value: number) => void; xp: number; level: number; levelTitle: string; levelProgress: number; soundscapeMix: SoundscapeMix; onSoundscapeChange: (value: SoundscapeMix) => void; onOpenBreak: () => void;
}) {
  return (
    <div className="grid gap-5 xl:grid-cols-[1.55fr_1fr]">
      <section className="instrument-card soft-grid reveal relative overflow-hidden rounded-3xl p-5 sm:p-7">
        <div className="absolute -right-20 -top-24 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
        <div className="relative flex flex-col gap-7">
          <div className="flex items-start justify-between">
            <div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Timer size={13} className="text-primary" /> Current instrument</div><h2 className="font-serif text-2xl font-bold text-foreground">Focus timer</h2></div>
            <div className="rounded-full border border-primary/20 bg-primary/10 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider text-primary">{timerRunning ? 'In session' : 'Ready when you are'}</div>
          </div>
          <div className="grid items-center gap-8 md:grid-cols-[1fr_.9fr]">
            <div className="flex flex-col items-center justify-center rounded-3xl border border-border/70 bg-background/40 py-9">
              <div className="mb-4 font-mono text-[10px] uppercase tracking-[.25em] text-muted-foreground">{mode === 'study' ? 'Deep study' : mode === 'short' ? 'Short break' : 'Long break'}</div>
              <div className="font-mono text-6xl font-medium tracking-[-.08em] text-foreground sm:text-7xl" data-testid="text-timer">{formatTime(timerSeconds)}</div>
              <div className="mt-7 flex items-center gap-3">
                <button type="button" data-testid="button-timer-toggle" onClick={onToggle} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-[0_8px_22px_rgba(181,132,255,.25)] transition hover:-translate-y-0.5 hover:brightness-110">{timerRunning ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}</button>
                <button type="button" data-testid="button-timer-reset" onClick={onReset} className="flex h-12 w-12 items-center justify-center rounded-2xl border border-border bg-secondary text-muted-foreground transition hover:text-foreground"><RotateCcw size={17} /></button>
              </div>
            </div>
            <div>
              <p className="mb-4 text-xs leading-5 text-muted-foreground">Use the rhythm that protects your attention. The timer quietly records each completed study block.</p>
              <div className="grid gap-2">
                <TimerModeButton active={mode === 'study'} label="Study" duration="25 min" icon={<Target size={15} />} onClick={() => onModeChange('study')} testId="button-mode-study" />
                <TimerModeButton active={mode === 'short'} label="Short break" duration="5 min" icon={<Coffee size={15} />} onClick={() => onModeChange('short')} testId="button-mode-short" />
                <TimerModeButton active={mode === 'long'} label="Long break" duration="15 min" icon={<Clock3 size={15} />} onClick={() => onModeChange('long')} testId="button-mode-long" />
              </div>
              <button type="button" data-testid="button-open-break" onClick={onOpenBreak} className="mt-5 flex items-center gap-2 text-xs font-semibold text-accent transition hover:text-foreground">Open a 30-minute reset <ChevronRight size={14} /></button>
            </div>
          </div>
        </div>
      </section>
      <GoalCard goalHours={goalHours} goalMinutes={goalMinutes} progress={progress} weeklyMinutes={weeklyMinutes} onGoalChange={onGoalChange} />
      <WeeklyChart studyLogs={studyLogs} week={week} weeklyMinutes={weeklyMinutes} todayMinutes={todayMinutes} />
       <XPCard xp={xp} level={level} levelTitle={levelTitle} levelProgress={levelProgress} />
       <SoundscapeMixer mix={soundscapeMix} onChange={onSoundscapeChange} />
    </div>
  );
}

function SoundscapeMixer({ mix, onChange }: { mix: SoundscapeMix; onChange: (value: SoundscapeMix) => void }) {
  const [playing, setPlaying] = useState(false);
  const rigRef = useRef<{ context: AudioContext; gains: GainNode[]; oscillators: OscillatorNode[] } | null>(null);

  const stopAudio = () => {
    if (!rigRef.current) return;
    rigRef.current.oscillators.forEach((oscillator) => oscillator.stop());
    void rigRef.current.context.close();
    rigRef.current = null;
    setPlaying(false);
  };

  const toggleAudio = () => {
    if (playing) {
      stopAudio();
      return;
    }
    const AudioContextConstructor = window.AudioContext;
    if (!AudioContextConstructor) return;
    const context = new AudioContextConstructor();
    const frequencies = [128, 196, 260];
    const levels = [mix.focus, mix.rain, mix.library];
    const gains: GainNode[] = [];
    const oscillators: OscillatorNode[] = [];
    frequencies.forEach((frequency, index) => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = index === 1 ? 'triangle' : 'sine';
      oscillator.frequency.value = frequency;
      gain.gain.value = (levels[index] / 100) * 0.025;
      oscillator.connect(gain).connect(context.destination);
      oscillator.start();
      oscillators.push(oscillator);
      gains.push(gain);
    });
    rigRef.current = { context, gains, oscillators };
    setPlaying(true);
  };

  useEffect(() => {
    if (!rigRef.current) return;
    [mix.focus, mix.rain, mix.library].forEach((level, index) => {
      rigRef.current?.gains[index].gain.setTargetAtTime((level / 100) * 0.025, rigRef.current.context.currentTime, 0.05);
    });
  }, [mix]);

  useEffect(() => () => {
    if (rigRef.current) {
      rigRef.current.oscillators.forEach((oscillator) => oscillator.stop());
      void rigRef.current.context.close();
    }
  }, []);

  const sliders = [
    ['focus', 'Focus hum', mix.focus, 'text-primary'],
    ['rain', 'Rain texture', mix.rain, 'text-accent'],
    ['library', 'Library hush', mix.library, 'text-chart-3'],
  ] as const;

  return (
    <section className="instrument-card reveal reveal-delay-3 rounded-3xl p-5 sm:p-7 xl:col-span-2">
      <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Music size={13} className="text-accent" /> Soundscape mixer</div>
          <h2 className="font-serif text-xl font-bold text-foreground">Shape the room around you</h2>
          <p className="mt-1 text-xs text-muted-foreground">A soft local audio bed for focus. Your mix stays in this browser.</p>
        </div>
        <button type="button" data-testid="button-soundscape-toggle" onClick={toggleAudio} className={`flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition ${playing ? 'bg-accent text-accent-foreground' : 'border border-border bg-secondary text-foreground hover:border-primary/40'}`}>
          {playing ? <VolumeX size={15} /> : <Volume2 size={15} />} {playing ? 'Mute soundscape' : 'Play soundscape'}
        </button>
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {sliders.map(([key, label, value, color]) => (
          <label key={key} className="rounded-2xl border border-border/70 bg-background/35 p-4">
            <div className="mb-3 flex items-center justify-between text-xs font-semibold text-foreground"><span className={color}>{label}</span><span className="font-mono text-[10px] text-muted-foreground">{value}%</span></div>
            <input type="range" min="0" max="100" value={value} onChange={(event) => onChange({ ...mix, [key]: Number(event.target.value) })} className="w-full accent-[hsl(var(--primary))]" />
          </label>
        ))}
      </div>
    </section>
  );
}

function TimerModeButton({ active, label, duration, icon, onClick, testId }: { active: boolean; label: string; duration: string; icon: React.ReactNode; onClick: () => void; testId: string }) {
  return <button type="button" data-testid={testId} onClick={onClick} className={`flex items-center justify-between rounded-2xl border px-3.5 py-3 text-left transition ${active ? 'border-primary/40 bg-primary/10 text-foreground' : 'border-border/70 bg-secondary/30 text-muted-foreground hover:border-primary/25 hover:text-foreground'}`}><span className="flex items-center gap-2.5 text-xs font-semibold"><span className={active ? 'text-primary' : 'text-muted-foreground'}>{icon}</span>{label}</span><span className="font-mono text-[10px] text-muted-foreground">{duration}</span></button>;
}

function GoalCard({ goalHours, goalMinutes, progress, weeklyMinutes, onGoalChange }: { goalHours: number; goalMinutes: number; progress: number; weeklyMinutes: number; onGoalChange: (value: number) => void }) {
  const circumference = 2 * Math.PI * 49;
  return (
    <section className="instrument-card reveal reveal-delay-1 rounded-3xl p-5 sm:p-7">
      <div className="mb-6 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Target size={13} className="text-accent" /> Weekly intention</div><h2 className="font-serif text-xl font-bold text-foreground">Make room for the work</h2></div><CalendarDays size={19} className="text-muted-foreground" /></div>
      <div className="flex items-center gap-5">
        <div className="relative h-32 w-32 shrink-0">
          <svg className="progress-ring h-full w-full" viewBox="0 0 120 120"><circle cx="60" cy="60" r="49" fill="none" stroke="hsl(var(--secondary))" strokeWidth="8" /><circle cx="60" cy="60" r="49" fill="none" stroke="hsl(var(--accent))" strokeLinecap="round" strokeWidth="8" strokeDasharray={circumference} strokeDashoffset={circumference - (circumference * progress) / 100} /></svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center"><span className="font-serif text-2xl font-bold text-foreground" data-testid="text-goal-progress">{progress}%</span><span className="font-mono text-[9px] uppercase text-muted-foreground">complete</span></div>
        </div>
        <div className="min-w-0"><div className="font-mono text-2xl text-foreground">{(weeklyMinutes / 60).toFixed(1)} <span className="text-sm text-muted-foreground">/ {goalHours}h</span></div><p className="mt-1 text-xs leading-5 text-muted-foreground">A small promise, repeated often.</p><label className="mt-4 flex items-center gap-2 text-[10px] uppercase tracking-wider text-muted-foreground">Goal hours <input data-testid="input-goal-hours" type="number" min="1" max="80" value={goalHours} onChange={(event) => onGoalChange(Math.max(1, Number(event.target.value) || 1))} className="w-16 rounded-lg border border-input bg-background/70 px-2 py-1 font-mono text-xs text-foreground outline-none" /></label></div>
      </div>
      <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-accent transition-all duration-500" style={{ width: `${progress}%` }} /></div>
    </section>
  );
}

function WeeklyChart({ studyLogs, week, weeklyMinutes, todayMinutes }: { studyLogs: Record<string, number>; week: { key: string; label: string; date: Date }[]; weeklyMinutes: number; todayMinutes: number }) {
  const max = Math.max(60, ...week.map((day) => studyLogs[day.key] ?? 0));
  return (
    <section className="instrument-card reveal reveal-delay-2 rounded-3xl p-5 sm:p-7">
      <div className="mb-7 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><BarChart3 size={13} className="text-primary" /> Signal history</div><h2 className="font-serif text-xl font-bold text-foreground">This week, in minutes</h2></div><div className="text-right"><div className="font-mono text-lg text-foreground" data-testid="text-weekly-minutes">{weeklyMinutes}</div><div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">total minutes</div></div></div>
      <div className="flex h-44 items-end justify-between gap-2 border-b border-border/70 pb-0">
        {week.map((day) => {
          const value = studyLogs[day.key] ?? 0;
          const height = Math.max(value ? 8 : 3, (value / max) * 100);
          const isToday = day.key === dayKey();
          return <div key={day.key} className="group flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="relative flex w-full flex-1 items-end justify-center"><div className={`w-full max-w-8 rounded-t-lg transition-all duration-500 group-hover:brightness-125 ${isToday ? 'bg-accent' : value ? 'bg-primary/65' : 'bg-secondary'}`} style={{ height: `${height}%` }}><span className="absolute -top-6 left-1/2 hidden -translate-x-1/2 rounded-md bg-popover px-1.5 py-1 font-mono text-[9px] text-foreground shadow-lg group-hover:block">{value}m</span></div></div><span className={`font-mono text-[10px] ${isToday ? 'font-bold text-accent' : 'text-muted-foreground'}`}>{day.label}</span></div>;
        })}
      </div>
      <div className="mt-4 flex items-center justify-between text-xs text-muted-foreground"><span><span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-accent" /> Today: <strong className="text-foreground">{todayMinutes} min</strong></span><span className="font-mono text-[10px] uppercase tracking-wider">7 day window</span></div>
    </section>
  );
}

function XPCard({ xp, level, levelTitle, levelProgress }: { xp: number; level: number; levelTitle: string; levelProgress: number }) {
  return (
    <section className="instrument-card reveal reveal-delay-3 overflow-hidden rounded-3xl p-5 sm:p-7">
      <div className="mb-6 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Trophy size={13} className="text-chart-3" /> Momentum index</div><h2 className="font-serif text-xl font-bold text-foreground">Attention compounds</h2></div><Flame size={20} className="text-chart-3" /></div>
       <div className="flex items-end justify-between gap-3"><div><span className="font-mono text-4xl tracking-[-.08em] text-foreground" data-testid="text-profile-xp">{xp.toLocaleString()}</span><span className="ml-2 font-mono text-xs text-muted-foreground">XP</span></div><span className="rounded-full border border-chart-3/30 bg-chart-3/10 px-2.5 py-1 text-right font-mono text-[10px] text-chart-3">LEVEL {level}<span className="block text-[9px] text-chart-3/70">{levelTitle}</span></span></div>
      <div className="mt-5 h-2 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-gradient-to-r from-primary to-accent transition-all duration-700" style={{ width: `${levelProgress}%` }} /></div>
      <div className="mt-2 flex justify-between font-mono text-[9px] uppercase tracking-wider text-muted-foreground"><span>Next level</span><span>{Math.max(0, 500 - (xp % 500))} XP to go</span></div>
       <div className="mt-6 grid grid-cols-3 gap-2 border-t border-border/70 pt-5"><div><div className="font-mono text-sm text-foreground">+10</div><div className="text-[10px] text-muted-foreground">focus minute</div></div><div><div className="font-mono text-sm text-foreground">+8</div><div className="text-[10px] text-muted-foreground">quiz answer</div></div><div><div className="font-mono text-sm text-foreground">+60</div><div className="text-[10px] text-muted-foreground">quiz finish</div></div></div>
    </section>
  );
}

function CalendarView({ assignments, month, onMonthChange, onAdd, onDelete }: {
  assignments: Assignment[];
  month: string;
  onMonthChange: (value: string) => void;
  onAdd: (assignment: Assignment) => void;
  onDelete: (id: string) => void;
}) {
  const [year, monthNumber] = month.split('-').map(Number);
  const [title, setTitle] = useState('');
  const [course, setCourse] = useState('');
  const [date, setDate] = useState(`${month}-01`);
  const monthStart = new Date(year, monthNumber - 1, 1);
  const daysInMonth = new Date(year, monthNumber, 0).getDate();
  const leadingDays = (monthStart.getDay() + 6) % 7;
  const cells = Array.from({ length: leadingDays + daysInMonth }, (_, index) => index < leadingDays ? null : index - leadingDays + 1);
  const monthLabel = monthStart.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  const moveMonth = (offset: number) => {
    const next = new Date(year, monthNumber - 1 + offset, 1);
    onMonthChange(`${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, '0')}`);
  };

  const addAssignment = () => {
    if (!title.trim() || !date) return;
    onAdd({ id: makeId('assignment'), title: title.trim(), course: course.trim() || 'Personal', date });
    setTitle('');
    setCourse('');
  };

  return (
    <div className="grid gap-5 xl:grid-cols-[1.35fr_.65fr]">
      <section className="instrument-card reveal rounded-3xl p-5 sm:p-7">
        <div className="mb-7 flex items-center justify-between">
          <div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><CalendarDays size={13} className="text-accent" /> Monthly grid</div><h2 className="font-serif text-2xl font-bold text-foreground">{monthLabel}</h2></div>
          <div className="flex items-center gap-2"><button type="button" aria-label="Previous month" onClick={() => moveMonth(-1)} className="rounded-xl border border-border bg-secondary p-2 text-muted-foreground transition hover:text-foreground"><ChevronLeft size={16} /></button><button type="button" aria-label="Next month" onClick={() => moveMonth(1)} className="rounded-xl border border-border bg-secondary p-2 text-muted-foreground transition hover:text-foreground"><ChevronRight size={16} /></button></div>
        </div>
        <div className="mb-2 grid grid-cols-7 gap-1 text-center font-mono text-[9px] uppercase tracking-wider text-muted-foreground">{['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map((day) => <div key={day} className="py-2">{day}</div>)}</div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((day, index) => {
            const key = day ? `${year}-${String(monthNumber).padStart(2, '0')}-${String(day).padStart(2, '0')}` : `blank-${index}`;
            const dayAssignments = day ? assignments.filter((assignment) => assignment.date === key) : [];
            return <div key={key} className={`min-h-24 rounded-2xl border p-2 ${day ? 'border-border/70 bg-background/25' : 'border-transparent'}`}>
              {day && <><div className={`mb-2 font-mono text-xs ${key === dayKey() ? 'font-bold text-accent' : 'text-muted-foreground'}`}>{day}</div><div className="grid gap-1">{dayAssignments.map((assignment) => <div key={assignment.id} className="group rounded-lg border border-primary/20 bg-primary/10 px-2 py-1 text-[10px] leading-4 text-foreground"><div className="flex items-start justify-between gap-1"><span className="line-clamp-2">{assignment.title}</span><button type="button" aria-label={`Delete ${assignment.title}`} onClick={() => onDelete(assignment.id)} className="hidden text-muted-foreground hover:text-destructive group-hover:block"><Trash2 size={11} /></button></div><span className="text-[9px] text-muted-foreground">{assignment.course}</span></div>)}</div></>}
            </div>;
          })}
        </div>
      </section>
      <section className="instrument-card reveal reveal-delay-1 rounded-3xl p-5 sm:p-7">
        <div className="mb-6 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><CalendarPlus size={13} className="text-primary" /> Add assignment</div><h2 className="font-serif text-xl font-bold text-foreground">Keep the next action visible.</h2></div><PanelRight size={18} className="text-muted-foreground" /></div>
        <div className="grid gap-4">
          <label className="grid gap-2 text-xs font-semibold text-foreground">Assignment title<input data-testid="input-assignment-title" value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Read chapter 4" className="rounded-xl border border-input bg-background/55 px-3 py-2.5 text-sm font-normal outline-none focus:border-primary/60" /></label>
          <label className="grid gap-2 text-xs font-semibold text-foreground">Course or context<input data-testid="input-assignment-course" value={course} onChange={(event) => setCourse(event.target.value)} placeholder="Biology" className="rounded-xl border border-input bg-background/55 px-3 py-2.5 text-sm font-normal outline-none focus:border-primary/60" /></label>
          <label className="grid gap-2 text-xs font-semibold text-foreground">Due date<input data-testid="input-assignment-date" type="date" value={date} onChange={(event) => setDate(event.target.value)} className="rounded-xl border border-input bg-background/55 px-3 py-2.5 text-sm font-normal outline-none focus:border-primary/60" /></label>
          <button type="button" data-testid="button-add-assignment" onClick={addAssignment} className="mt-2 flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-bold text-primary-foreground transition hover:brightness-110"><Plus size={15} /> Add to calendar</button>
        </div>
        <div className="mt-7 border-t border-border/70 pt-5"><div className="mb-3 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">Upcoming</div>{assignments.filter((assignment) => assignment.date >= dayKey()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4).map((assignment) => <div key={assignment.id} className="mb-2 flex items-center justify-between rounded-xl bg-secondary/40 px-3 py-2 text-xs"><span className="truncate text-foreground">{assignment.title}</span><span className="ml-3 shrink-0 font-mono text-[10px] text-muted-foreground">{assignment.date.slice(5)}</span></div>)}{!assignments.some((assignment) => assignment.date >= dayKey()) && <p className="text-xs leading-5 text-muted-foreground">No upcoming assignments. Add one to give the week a shape.</p>}</div>
      </section>
    </div>
  );
}

function NotesView({ notes, profileName, onNameChange, onChange }: { notes: StickyNote[]; profileName: string; onNameChange: (value: string) => void; onChange: (value: StickyNote[]) => void }) {
  const colors: StickyNote['color'][] = ['violet', 'mint', 'amber', 'rose'];
  const addNote = () => onChange([{ id: makeId('note'), title: 'Untitled idea', content: '', color: colors[notes.length % colors.length], updatedAt: new Date().toISOString() }, ...notes]);
  const updateNote = (id: string, patch: Partial<StickyNote>) => onChange(notes.map((note) => note.id === id ? { ...note, ...patch, updatedAt: new Date().toISOString() } : note));
  return (
    <div className="instrument-card reveal rounded-3xl p-5 sm:p-7">
      <div className="mb-7 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><StickyNote size={13} className="text-chart-3" /> Notes / corkboard</div><h2 className="font-serif text-2xl font-bold text-foreground">Ideas that stay editable.</h2><p className="mt-2 max-w-xl text-sm leading-6 text-muted-foreground">No random usernames, no locked fields. Everything here belongs to you and saves locally as you type.</p></div><div className="flex flex-wrap items-center gap-2"><label className="flex items-center gap-2 rounded-xl border border-border bg-background/40 px-3 py-2 text-xs text-muted-foreground"><span>Workspace name</span><input value={profileName} onChange={(event) => onNameChange(event.target.value)} className="w-28 bg-transparent text-right font-semibold text-foreground outline-none" /></label><button type="button" data-testid="button-add-note" onClick={addNote} className="flex items-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-xs font-bold text-primary-foreground transition hover:brightness-110"><Plus size={14} /> New note</button></div></div>
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {notes.map((note) => <article key={note.id} className={`sticky-note sticky-${note.color} rounded-3xl border p-5 shadow-xl`}>
          <div className="mb-4 flex items-center justify-between gap-3"><input value={note.title} onChange={(event) => updateNote(note.id, { title: event.target.value })} className="min-w-0 flex-1 bg-transparent font-serif text-lg font-bold text-foreground outline-none" /><button type="button" aria-label={`Delete ${note.title}`} onClick={() => onChange(notes.filter((item) => item.id !== note.id))} className="rounded-lg p-1.5 text-muted-foreground transition hover:bg-black/10 hover:text-destructive"><Trash2 size={14} /></button></div>
          <textarea value={note.content} onChange={(event) => updateNote(note.id, { content: event.target.value })} placeholder="Write the thought down..." className="min-h-32 w-full resize-none bg-transparent text-sm leading-6 text-foreground outline-none placeholder:text-muted-foreground/70" />
          <div className="mt-5 flex items-center justify-between border-t border-black/10 pt-3"><select value={note.color} onChange={(event) => updateNote(note.id, { color: event.target.value as StickyNote['color'] })} className="bg-transparent font-mono text-[9px] uppercase tracking-wider text-muted-foreground outline-none"><option value="violet">Violet</option><option value="mint">Mint</option><option value="amber">Amber</option><option value="rose">Rose</option></select><span className="font-mono text-[9px] text-muted-foreground">{profileName || 'Workspace'}</span></div>
        </article>)}
      </div>
    </div>
  );
}

function CalculatorView({ expression, result, onExpressionChange, onEvaluate, onClear }: { expression: string; result: string; onExpressionChange: (value: string) => void; onEvaluate: () => void; onClear: () => void }) {
  const buttons = ['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '%', '+'];
  return (
    <div className="mx-auto grid max-w-4xl gap-5 lg:grid-cols-[.8fr_1.2fr]">
      <section className="instrument-card reveal rounded-3xl p-5 sm:p-7">
        <div className="mb-6"><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Calculator size={13} className="text-accent" /> Scientific calculator</div><h2 className="font-serif text-2xl font-bold text-foreground">A clean scratchpad.</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">Use the grid for quick study calculations. Unfinished or invalid expressions fail safely.</p></div>
        <div className="rounded-2xl border border-border bg-background/70 p-4 text-right"><div className="min-h-7 break-all font-mono text-sm text-muted-foreground">{expression || '0'}</div><div className="mt-2 min-h-12 break-all font-mono text-3xl text-foreground">{result || '—'}</div></div>
        <div className="mt-4 grid grid-cols-4 gap-2">{buttons.map((button) => <button type="button" key={button} data-testid={`button-calc-${button}`} onClick={() => onExpressionChange(`${expression}${button}`)} className={`rounded-2xl border py-3.5 font-mono text-sm transition hover:border-primary/50 hover:bg-primary/10 ${['/', '*', '-', '+', '%'].includes(button) ? 'text-primary' : 'border-border bg-secondary/35 text-foreground'}`}>{button}</button>)}<button type="button" onClick={onClear} className="rounded-2xl border border-destructive/20 bg-destructive/10 py-3.5 font-mono text-sm text-destructive">C</button><button type="button" onClick={() => onExpressionChange(expression.slice(0, -1))} className="rounded-2xl border border-border bg-secondary/35 py-3.5 font-mono text-sm text-foreground">⌫</button><button type="button" onClick={onEvaluate} className="col-span-2 rounded-2xl bg-primary py-3.5 font-mono text-sm font-bold text-primary-foreground transition hover:brightness-110">= Evaluate</button></div>
      </section>
      <section className="instrument-card reveal reveal-delay-1 rounded-3xl p-5 sm:p-7"><div className="mb-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Save size={13} className="text-accent" /> Calculator memory</div><p className="text-sm leading-6 text-muted-foreground">Your current expression and last result are persisted locally, so you can switch tools without losing the scratch work.</p><div className="mt-6 rounded-2xl border border-border/70 bg-background/30 p-4 font-mono text-xs leading-6 text-muted-foreground">Allowed operators<br /><span className="text-foreground">+  −  ×  ÷  %  ( )</span><br /><br />Tip<br /><span className="text-accent">Try (25 * 4) / 5</span></div></section>
    </div>
  );
}

function SettingsView({ settings, username, onChange, onUsernameChange }: { settings: ThemeSettings; username: string; onChange: (value: ThemeSettings) => void; onUsernameChange: (value: string) => void }) {
  const [draftUsername, setDraftUsername] = useState(username);
  useEffect(() => setDraftUsername(username), [username]);
  const toggles: { key: keyof ThemeSettings; label: string; description: string }[] = [
    { key: 'ambientGrid', label: 'Ambient grid texture', description: 'Keep the subtle instrument-panel texture visible.' },
    { key: 'compact', label: 'Compact workspace', description: 'Tighten spacing when you want more information at once.' },
    { key: 'reducedMotion', label: 'Reduced motion', description: 'Turn off entrance and hover motion for a quieter session.' },
    { key: 'highContrast', label: 'High contrast accents', description: 'Increase border and text contrast across the shell.' },
  ];
  return (
    <div className="mx-auto grid max-w-4xl gap-5 lg:grid-cols-[1.2fr_.8fr]">
      <section className="instrument-card reveal rounded-3xl p-5 sm:p-7"><div className="mb-7"><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Settings size={13} className="text-accent" /> Settings / preferences</div><h2 className="font-serif text-2xl font-bold text-foreground">Tune the environment.</h2><p className="mt-2 text-sm leading-6 text-muted-foreground">These preferences are saved locally and affect the whole workspace.</p></div><div className="mb-5 rounded-2xl border border-border/70 bg-background/30 p-4"><label className="grid gap-2 text-xs font-semibold text-foreground">Profile name<input data-testid="input-profile-name" value={draftUsername} onChange={(event) => setDraftUsername(event.target.value)} className="rounded-xl border border-input bg-background/55 px-3 py-2.5 text-sm font-normal outline-none focus:border-primary/60" /></label><button type="button" data-testid="button-save-profile-name" onClick={() => onUsernameChange(draftUsername.trim() || 'Ari Rowan')} className="mt-3 flex items-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-xs font-bold text-primary-foreground transition hover:brightness-110"><Save size={14} /> Save profile</button></div><div className="grid gap-3">{toggles.map((toggle) => <button type="button" key={toggle.key} onClick={() => onChange({ ...settings, [toggle.key]: !settings[toggle.key] })} className="flex items-center justify-between gap-4 rounded-2xl border border-border/70 bg-background/30 p-4 text-left transition hover:border-primary/40"><span><span className="block text-sm font-semibold text-foreground">{toggle.label}</span><span className="mt-1 block text-xs leading-5 text-muted-foreground">{toggle.description}</span></span><span className={`relative h-6 w-11 shrink-0 rounded-full transition ${settings[toggle.key] ? 'bg-accent' : 'bg-secondary'}`}><span className={`absolute top-1 h-4 w-4 rounded-full bg-foreground transition ${settings[toggle.key] ? 'left-6' : 'left-1'}`} /></span></button>)}</div></section>
      <section className="instrument-card reveal reveal-delay-1 rounded-3xl p-5 sm:p-7"><div className="mb-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Moon size={13} className="text-primary" /> Theme profile</div><div className="rounded-2xl border border-primary/20 bg-primary/10 p-5"><div className="font-serif text-lg font-bold text-foreground">Midnight focus</div><p className="mt-2 text-xs leading-5 text-muted-foreground">Deep charcoal surfaces, violet control signals, and mint progress markers keep the app dark without making it feel flat.</p></div><div className="mt-5 grid grid-cols-4 gap-2">{['#17131f', '#b47aff', '#6ff0c3', '#f7bd6b'].map((color) => <div key={color} style={{ backgroundColor: color }} className="h-10 rounded-xl border border-white/10" />)}</div></section>
    </div>
  );
}

function Sidekick({ open, messages, input, onToggle, onInput, onSend }: { open: boolean; messages: ChatMessage[]; input: string; onToggle: () => void; onInput: (value: string) => void; onSend: () => void }) {
  return <div className="fixed bottom-5 right-5 z-50">
    {open && <section className="sidekick-panel instrument-card mb-3 flex h-[460px] w-[min(360px,calc(100vw-2rem))] flex-col overflow-hidden rounded-3xl">
      <div className="flex items-center justify-between border-b border-border/70 px-4 py-3"><div className="flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-xl bg-accent/15 text-accent"><MessageCircle size={15} /></div><div><div className="text-xs font-bold text-foreground">Local sidekick</div><div className="font-mono text-[9px] uppercase tracking-wider text-muted-foreground">notes-aware / offline</div></div></div><button type="button" aria-label="Close sidekick" onClick={onToggle} className="rounded-lg p-1.5 text-muted-foreground hover:text-foreground"><X size={15} /></button></div>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`max-w-[88%] rounded-2xl px-3 py-2.5 text-xs leading-5 ${message.role === 'user' ? 'ml-auto bg-primary text-primary-foreground' : 'bg-secondary/70 text-foreground'}`}>{message.text}</div>)}</div>
      <form onSubmit={(event) => { event.preventDefault(); onSend(); }} className="border-t border-border/70 p-3"><div className="flex items-center gap-2 rounded-xl border border-input bg-background/55 px-3"><input aria-label="Ask the local sidekick" value={input} onChange={(event) => onInput(event.target.value)} placeholder="Ask about your notes..." className="min-w-0 flex-1 bg-transparent py-2.5 text-xs text-foreground outline-none placeholder:text-muted-foreground" /><button type="submit" aria-label="Send message" className="text-accent transition hover:text-foreground"><Send size={15} /></button></div></form>
    </section>}
    <button type="button" data-testid="button-sidekick" aria-label={open ? 'Close local sidekick' : 'Open local sidekick'} onClick={onToggle} className={`ml-auto flex h-14 w-14 items-center justify-center rounded-2xl shadow-[0_10px_30px_rgba(0,0,0,.3)] transition hover:-translate-y-1 ${open ? 'bg-secondary text-foreground' : 'bg-accent text-accent-foreground'}`}>{open ? <X size={20} /> : <MessageCircle size={20} />}</button>
  </div>;
}

function QuizView({ notes, setNotes, quizLength, setQuizLength, questionType, setQuestionType, quiz, quizIndex, setQuizIndex, quizAnswers, quizResults, onGenerate, onAnswer, onReset, onClaimBonus, bonusClaimed }: {
  notes: string; setNotes: (value: string) => void; quizLength: number; setQuizLength: (value: number) => void; questionType: QuestionType; setQuestionType: (value: QuestionType) => void; quiz: Quiz | null; quizIndex: number; setQuizIndex: (value: number) => void; quizAnswers: Record<number, string>; quizResults: Record<number, boolean>; onGenerate: () => void; onAnswer: (answer: string) => void; onReset: () => void; onClaimBonus: () => void; bonusClaimed: boolean;
}) {
  const wordCount = notes.trim() ? notes.trim().split(/\s+/).length : 0;
  const finished = Boolean(quiz && quizIndex >= quiz.questions.length - 1 && quizResults[quizIndex] !== undefined);
  const score = quiz ? Object.values(quizResults).filter(Boolean).length : 0;
  return (
    <div className="grid gap-5 xl:grid-cols-[.9fr_1.35fr]">
      <section className="instrument-card reveal rounded-3xl p-5 sm:p-7">
        <div className="mb-6 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><NotebookPen size={13} className="text-accent" /> Source material</div><h2 className="font-serif text-2xl font-bold text-foreground">Your notes, your test</h2></div><div className="rounded-full border border-accent/25 bg-accent/10 px-2.5 py-1 font-mono text-[9px] uppercase tracking-wider text-accent">Private</div></div>
        <label htmlFor="notes-input" className="mb-2 block text-xs font-semibold text-foreground">Paste a chapter, lecture, or rough thinking</label>
         <textarea id="notes-input" data-testid="textarea-notes" value={notes} onChange={(event) => setNotes(event.target.value)} maxLength={50000} className="h-60 w-full resize-none rounded-2xl border border-input bg-background/60 p-4 text-sm leading-6 text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary/60" placeholder="Your notes live here..." />
        <div className="mt-2 flex justify-between font-mono text-[9px] uppercase tracking-wider text-muted-foreground"><span>{wordCount.toLocaleString()} / 5,000 words</span><span className={wordCount > 5000 ? 'text-destructive' : 'text-accent'}>{wordCount > 5000 ? 'Trim notes to continue' : 'Within range'}</span></div>
        <div className="my-6 h-px bg-border" />
        <div className="mb-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><SlidersIcon /> Generation controls</div>
        <div className="mb-5"><div className="mb-2 text-xs font-semibold text-foreground">Quiz length</div><div className="grid grid-cols-3 gap-2">{[5, 10, 15].map((length) => <button type="button" key={length} data-testid={`button-quiz-length-${length}`} onClick={() => setQuizLength(length)} className={`rounded-xl border py-2.5 font-mono text-xs transition ${quizLength === length ? 'border-primary/50 bg-primary/15 text-primary' : 'border-border bg-secondary/30 text-muted-foreground hover:text-foreground'}`}>{length} questions</button>)}</div></div>
        <div><div className="mb-2 text-xs font-semibold text-foreground">Question type</div><div className="grid grid-cols-2 gap-2"><button type="button" data-testid="button-question-multiple" onClick={() => setQuestionType('multiple')} className={`rounded-xl border px-3 py-2.5 text-left text-xs transition ${questionType === 'multiple' ? 'border-primary/50 bg-primary/15 text-primary' : 'border-border bg-secondary/30 text-muted-foreground hover:text-foreground'}`}><ListChecks size={15} className="mb-1" />Multiple-choice</button><button type="button" data-testid="button-question-true-false" onClick={() => setQuestionType('true-false')} className={`rounded-xl border px-3 py-2.5 text-left text-xs transition ${questionType === 'true-false' ? 'border-primary/50 bg-primary/15 text-primary' : 'border-border bg-secondary/30 text-muted-foreground hover:text-foreground'}`}><CircleHelp size={15} className="mb-1" />True / false</button></div></div>
        <button type="button" data-testid="button-generate-quiz" disabled={wordCount > 5000} onClick={onGenerate} className="mt-7 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground shadow-[0_8px_24px_rgba(181,132,255,.2)] transition hover:-translate-y-0.5 hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"><WandSparkles size={17} /> Generate sentence quiz</button>
        <div className="mt-4 flex items-center gap-2 text-[10px] leading-4 text-muted-foreground"><Lock size={12} className="shrink-0 text-accent" /> Nothing leaves this browser. Your notes are stored locally.</div>
      </section>
      <section className="instrument-card reveal reveal-delay-1 min-h-[560px] rounded-3xl p-5 sm:p-7">
        {!quiz ? <QuizEmpty onGenerate={onGenerate} /> : finished ? <QuizResults score={score} total={quiz.questions.length} bonusClaimed={bonusClaimed} onClaimBonus={onClaimBonus} onReset={onReset} /> : <QuizQuestionWorkspace quiz={quiz} quizIndex={quizIndex} answer={quizAnswers[quizIndex]} result={quizResults[quizIndex]} onAnswer={onAnswer} onNext={() => setQuizIndex(Math.min(quiz.questions.length - 1, quizIndex + 1))} onPrevious={() => setQuizIndex(Math.max(0, quizIndex - 1))} />}</section>
    </div>
  );
}

function SlidersIcon() { return <span className="inline-flex h-3.5 w-3.5 items-center justify-center text-primary"><Settings size={13} /></span>; }

function QuizEmpty({ onGenerate }: { onGenerate: () => void }) {
  return <div className="flex min-h-[520px] flex-col items-center justify-center text-center"><div className="mb-6 flex h-20 w-20 items-center justify-center rounded-3xl border border-primary/20 bg-primary/10 text-primary"><Sparkles size={31} /></div><h3 className="font-serif text-2xl font-bold text-foreground">The studio is ready.</h3><p className="mt-3 max-w-sm text-sm leading-6 text-muted-foreground">Shape a quiz from the notes on the left. Each question is built around a sentence so you practice the exact material you wrote.</p><button type="button" data-testid="button-empty-generate" onClick={onGenerate} className="mt-7 flex items-center gap-2 rounded-xl border border-border bg-secondary px-4 py-2.5 text-xs font-semibold text-foreground transition hover:border-primary/40"><WandSparkles size={14} /> Build a quiz</button></div>;
}

function QuizQuestionWorkspace({ quiz, quizIndex, answer, result, onAnswer, onNext, onPrevious }: { quiz: Quiz; quizIndex: number; answer?: string; result?: boolean; onAnswer: (answer: string) => void; onNext: () => void; onPrevious: () => void }) {
  const question = quiz.questions[quizIndex];
  const answered = result !== undefined;
  return <div className="flex min-h-[520px] flex-col"><div className="mb-7 flex items-start justify-between"><div><div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.2em] text-muted-foreground"><Lightbulb size={13} className="text-chart-3" /> Active recall session</div><h2 className="font-serif text-2xl font-bold text-foreground">One idea at a time</h2></div><div className="text-right"><div className="font-mono text-sm text-foreground" data-testid="text-question-progress">{String(quizIndex + 1).padStart(2, '0')} <span className="text-muted-foreground">/ {String(quiz.questions.length).padStart(2, '0')}</span></div><div className="mt-1 font-mono text-[9px] uppercase tracking-wider text-muted-foreground">question</div></div></div><div className="mb-8 h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${((quizIndex + 1) / quiz.questions.length) * 100}%` }} /></div><div className="rounded-2xl border border-border bg-background/45 p-5 sm:p-7"><div className="mb-2 font-mono text-[10px] uppercase tracking-[.2em] text-primary">{question.type === 'multiple' ? 'Multiple choice' : 'True / false'}</div><h3 className="max-w-2xl font-serif text-xl font-semibold leading-8 text-foreground sm:text-2xl" data-testid={`text-question-${quizIndex}`}>{question.prompt}</h3></div><div className="mt-5 grid gap-3">{question.options.map((option, index) => { const selected = answer === option; const correct = answered && option === question.answer; return <button type="button" key={`${question.id}-${index}`} data-testid={`button-answer-${quizIndex}-${index}`} onClick={() => onAnswer(option)} disabled={answered} className={`quiz-option flex items-start gap-3 rounded-2xl border p-4 text-left text-sm leading-5 ${correct ? 'border-accent/50 bg-accent/10 text-foreground' : selected && !result ? 'border-destructive/50 bg-destructive/10 text-foreground' : 'border-border bg-secondary/20 text-muted-foreground hover:border-primary/40 hover:text-foreground'} disabled:cursor-default`}><span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg font-mono text-[10px] ${correct ? 'bg-accent text-accent-foreground' : 'bg-secondary text-muted-foreground'}`}>{correct ? <Check size={13} /> : String.fromCharCode(65 + index)}</span><span>{option}</span></button>; })}</div>{answered && <div className={`mt-5 rounded-2xl border p-4 ${result ? 'border-accent/30 bg-accent/8' : 'border-chart-3/30 bg-chart-3/8'}`}><div className="flex items-center gap-2 text-sm font-bold text-foreground">{result ? <CheckCircle2 size={17} className="text-accent" /> : <Lightbulb size={17} className="text-chart-3" />}{result ? 'Good retrieval.' : 'Keep the thread.'}</div><p className="mt-1 text-xs leading-5 text-muted-foreground">{question.explanation}</p></div>}<div className="mt-auto flex items-center justify-between border-t border-border/70 pt-6"><button type="button" data-testid="button-quiz-previous" onClick={onPrevious} disabled={quizIndex === 0} className="rounded-xl px-3 py-2 text-xs font-semibold text-muted-foreground transition hover:text-foreground disabled:opacity-30">Previous</button>{answered && <button type="button" data-testid="button-quiz-next" onClick={onNext} className="flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground transition hover:brightness-110">{quizIndex === quiz.questions.length - 1 ? 'See insights' : 'Next question'} <ArrowIcon /></button>}</div></div>;
}

function ArrowIcon() { return <ChevronRight size={14} />; }

function QuizResults({ score, total, bonusClaimed, onClaimBonus, onReset }: { score: number; total: number; bonusClaimed: boolean; onClaimBonus: () => void; onReset: () => void }) {
  const percent = Math.round((score / total) * 100);
  return <div className="flex min-h-[520px] flex-col items-center justify-center text-center"><div className="mb-5 flex h-20 w-20 items-center justify-center rounded-3xl border border-accent/25 bg-accent/10 text-accent"><Award size={34} /></div><div className="font-mono text-[10px] uppercase tracking-[.25em] text-accent">Session complete</div><h3 className="mt-3 font-serif text-3xl font-bold text-foreground">You kept the signal.</h3><p className="mt-3 text-sm text-muted-foreground">A clear result is useful. The next pass makes it yours.</p><div className="my-8 flex items-end gap-2"><span className="font-mono text-6xl tracking-[-.08em] text-foreground" data-testid="text-quiz-score">{score}</span><span className="mb-2 font-mono text-xl text-muted-foreground">/ {total}</span><span className="mb-2 ml-2 rounded-full bg-primary/10 px-2 py-1 font-mono text-[10px] text-primary">{percent}%</span></div><div className="flex flex-wrap justify-center gap-3"><button type="button" data-testid="button-claim-bonus" onClick={onClaimBonus} disabled={bonusClaimed} className="flex items-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-xs font-bold text-accent-foreground transition hover:brightness-110 disabled:opacity-50">{bonusClaimed ? <Check size={14} /> : <Zap size={14} />}{bonusClaimed ? 'Bonus claimed' : 'Claim +60 XP'}</button><button type="button" data-testid="button-retake-quiz" onClick={onReset} className="flex items-center gap-2 rounded-xl border border-border bg-secondary px-4 py-2.5 text-xs font-semibold text-foreground transition hover:border-primary/40"><RefreshCcw size={14} /> Review again</button></div><div className="mt-9 grid w-full max-w-sm grid-cols-3 gap-2 border-t border-border pt-5 text-left"><div><div className="font-mono text-sm text-foreground">{score}</div><div className="text-[10px] text-muted-foreground">recalled</div></div><div><div className="font-mono text-sm text-foreground">{total - score}</div><div className="text-[10px] text-muted-foreground">to revisit</div></div><div><div className="font-mono text-sm text-accent">+{score * 8}</div><div className="text-[10px] text-muted-foreground">XP earned</div></div></div></div>;
}

function BreakOverlay({ seconds, onSkip }: { seconds: number; onSkip: () => void }) {
  return <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#0b0910]/90 p-5 backdrop-blur-md"><div className="instrument-card relative w-full max-w-lg overflow-hidden rounded-3xl p-7 text-center sm:p-10"><div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary via-accent to-primary" /><div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-accent/10 text-accent"><Coffee size={28} /></div><div className="font-mono text-[10px] uppercase tracking-[.25em] text-accent">Brain break protocol</div><h2 className="mt-3 font-serif text-3xl font-bold text-foreground">Time for a quick brain break!</h2><p className="mx-auto mt-4 max-w-sm text-sm leading-6 text-muted-foreground">You've been studying hard for 30 minutes. Unwind your mind with today's word mystery puzzle.</p><div className="my-8 font-mono text-5xl tracking-[-.08em] text-foreground" data-testid="text-break-countdown">{formatTime(seconds)}</div><div className="flex flex-col gap-3 sm:flex-row sm:justify-center"><a href="https://vercel.app" target="_blank" rel="noreferrer" data-testid="link-break-escape" className="flex items-center justify-center gap-2 rounded-xl border border-border bg-secondary px-4 py-3 text-xs font-semibold text-foreground transition hover:border-primary/40">Open today's word mystery <ExternalLink size={14} /></a><button type="button" data-testid="button-skip-break" onClick={onSkip} className="flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-bold text-primary-foreground transition hover:brightness-110">Skip Break / Return to Workspace <SkipForward size={14} /></button></div><div className="mt-7 flex items-center justify-center gap-2 font-mono text-[9px] uppercase tracking-wider text-muted-foreground"><Send size={11} /> The next block starts when you choose it</div></div></div>;
}

export default App;